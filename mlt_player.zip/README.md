<!-- README.md -->

# MLT Player

A proof-of-concept desktop media player built with **Flutter** and **MLT (Media Lovin' Toolkit)**.

The project is being developed incrementally as a series of small technical proofs. The immediate goal is to build a VLC-style media player with Flutter providing the application UI while MLT handles media decoding, playback, seeking, audio, timing, and eventually more advanced media-processing features.

## Current Status

The core playback architecture is working.

Completed:

* Flutter Linux desktop application
* Native C bridge between Dart and MLT
* Dart FFI communication with `libmlt`
* MLT runtime initialization
* Media file loading
* Media metadata probing
* Duration reporting
* Frame-rate reporting
* Resolution reporting
* Play
* Pause
* Seeking
* Playback-position tracking
* Audio playback
* Embedded video inside the Flutter UI
* Native Flutter Linux texture registration
* MLT video frames converted to RGBA
* RGBA frames uploaded to an OpenGL texture
* OpenGL texture displayed using Flutter's `Texture` widget
* SDL video popup eliminated

The project currently uses **MLT 7.22.0**.

## Architecture

The application is intentionally divided into layers.

```text
Flutter UI
    │
    │ Dart FFI
    ▼
libmlt_bridge.so
    │
    ▼
MLT
    │
    ├── Producer
    │     └── media decoding
    │
    └── sdl2_audio consumer
          │
          ├── audio ───────────────► speakers
          │
          └── consumer-frame-show
                    │
                    ▼
               MLT frame
                    │
              RGBA conversion
                    │
                    ▼
              native frame buffer
                    │
                    ▼
              OpenGL texture
                    │
                    ▼
          Flutter Texture widget
                    │
                    ▼
             embedded video
```

Flutter owns the application window, player controls, layout, and user interaction.

MLT owns media decoding and playback.

The native bridge connects the two.

## Project Structure

```text
mlt_player/
├── lib/
│   └── main.dart
│
├── native/
│   ├── mlt_bridge.c
│   ├── mlt_bridge.h
│   ├── mlt_smoke.c
│   └── mlt_smoke
│
├── linux/
│   ├── CMakeLists.txt
│   └── runner/
│       └── my_application.cc
│
├── pubspec.yaml
└── README.md
```

### `lib/main.dart`

Flutter application and player UI.

Responsibilities currently include:

* file selection
* playback controls
* seek bar
* playback-position polling
* media metadata display
* Flutter texture display
* Dart FFI bindings

### `native/mlt_bridge.c`

Native media engine bridge.

Responsibilities currently include:

* MLT initialization
* media producer creation
* profile detection
* media probing
* playback
* pause
* seeking
* playback-position reporting
* SDL audio consumer
* MLT frame callbacks
* RGBA frame extraction
* native frame buffering
* OpenGL texture updates
* Flutter texture registration

### `native/mlt_bridge.h`

Public native bridge interface shared between the Flutter Linux runner and the native MLT implementation.

### `linux/runner/my_application.cc`

Flutter Linux runner integration.

In addition to normal Flutter Linux startup, it registers the native video texture with Flutter after the Flutter engine begins rendering.

### `linux/CMakeLists.txt`

Build configuration for:

* Flutter Linux
* MLT
* GTK
* libepoxy / OpenGL
* `libmlt_bridge.so`

## Requirements

The current proof of concept is being developed on Linux.

Required system packages include:

```bash
sudo apt install \
  melt \
  libmlt-dev \
  libmlt++-dev \
  pkg-config \
  build-essential
```

The current development machine reports:

```text
melt 7.22.0
```

MLT development availability can be checked with:

```bash
pkg-config --modversion mlt-framework-7
```

Expected result on the current system:

```text
7.22.0
```

Flutter Linux desktop support must also be configured.

Check with:

```bash
flutter doctor
```

## Flutter Dependencies

The project currently uses:

```yaml
ffi
file_selector
```

These provide:

* Dart native FFI support
* native desktop file selection

Install project dependencies with:

```bash
flutter pub get
```

## Running

From the project root:

```bash
flutter run -d linux
```

For changes involving native C/C++, CMake, or the Linux runner, use a clean rebuild:

```bash
flutter clean
flutter pub get
flutter run -d linux
```

Hot reload is useful for Dart/UI changes, but native bridge changes require recompilation.

## Native MLT Smoke Test

Before Flutter integration was added, MLT was verified independently with:

```bash
gcc native/mlt_smoke.c \
  $(pkg-config --cflags --libs mlt-framework-7) \
  -o native/mlt_smoke
```

Run:

```bash
./native/mlt_smoke
```

The current system reports:

```text
MLT initialized successfully.
MLT version: 7.22.0
MLT module directory: /usr/lib/x86_64-linux-gnu/mlt-7
```

This isolates MLT installation problems from Flutter integration problems.

## Playback Design

The first playback proof used MLT's `sdl2` consumer.

That proved:

```text
Flutter
   ↓
FFI
   ↓
MLT producer
   ↓
SDL video + audio
```

However, `sdl2` owns its own video window.

That architecture was intentionally temporary.

The current implementation instead uses:

```text
MLT producer
      ↓
sdl2_audio
      │
      ├── audio
      │
      └── video-frame timing event
                 ↓
          MLT RGBA frame
                 ↓
          Flutter texture
```

This keeps the video inside the Flutter interface while MLT continues to handle playback timing and audio.

## Current Player Features

The current UI supports:

* Open Media
* Play
* Pause
* Seek bar
* Back 10 seconds
* Forward 10 seconds
* Current playback time
* Total duration
* Media filename
* Full source path
* Resolution
* Frame rate
* Frame count
* Embedded video
* Audio playback

## Proof-of-Concept Milestones

### POC 0 — Flutter ↔ MLT

Completed.

Flutter successfully loads the native bridge through Dart FFI and queries the running MLT version.

```text
Flutter
   ↓
Dart FFI
   ↓
libmlt_bridge.so
   ↓
MLT
```

### POC 1 — Media Loading

Completed.

MLT opens real media files and reports:

* width
* height
* frame rate
* frame count
* duration

### POC 2 — Playback Transport

Completed.

MLT provides:

* play
* pause
* seek
* playback position
* audio output

### POC 3 — Embedded Video

Completed.

MLT video frames are displayed directly inside Flutter using a native OpenGL texture.

No separate SDL video window is required.

## Next Milestone

The next phase is to turn the successful proof of concept into a dependable media-player foundation.

Likely next targets include:

* volume control
* mute
* end-of-file handling
* keyboard controls
* spacebar play/pause
* arrow-key seeking
* fullscreen
* opening a new file during playback
* robust repeated play/pause behavior
* robust repeated seeking
* proper playback lifecycle cleanup
* aspect-ratio handling
* resize behavior
* drag-and-drop media opening
* error handling for unsupported/corrupt media

Once that layer is stable, the project can begin exposing more of MLT's larger media-processing architecture.

## Long-Term Direction

This project begins as a media player, but the player is primarily a foundation for experimenting with MLT from Flutter.

MLT provides much more than simple playback, including:

* producers
* playlists
* multitracks
* tractors
* filters
* transitions
* compositing
* audio processing
* rendering
* media graphs

The long-term project can therefore evolve beyond a VLC-style player without replacing the underlying media engine.

The guiding architecture remains:

```text
Flutter owns the application.

MLT owns the media.
```

## Development Philosophy

The project is being built through small proof-of-concept milestones.

Each new capability should first answer one narrow technical question before being incorporated into the larger application.

This keeps failures isolated and prevents the project from building large abstractions around assumptions that have not yet been proven.
