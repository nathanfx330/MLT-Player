// lib/main.dart

import 'dart:async';
import 'dart:ffi';
import 'dart:io';
import 'dart:ui' show FontFeature;

import 'package:ffi/ffi.dart';
import 'package:file_selector/file_selector.dart';
import 'package:flutter/material.dart';

typedef MltInitNative = Int32 Function();
typedef MltInitDart = int Function();

typedef MltVersionNative = Pointer<Utf8> Function();
typedef MltVersionDart = Pointer<Utf8> Function();

typedef MltStringNative = Pointer<Utf8> Function();
typedef MltStringDart = Pointer<Utf8> Function();

typedef MltOpenNative = Int32 Function(Pointer<Utf8>);
typedef MltOpenDart = int Function(Pointer<Utf8>);

typedef MltCommandNative = Int32 Function();
typedef MltCommandDart = int Function();

typedef MltSeekNative = Int32 Function(Int64);
typedef MltSeekDart = int Function(int);

typedef MltInt64Native = Int64 Function();
typedef MltInt64Dart = int Function();

typedef MltInt32Native = Int32 Function();
typedef MltInt32Dart = int Function();

typedef MltDoubleNative = Double Function();
typedef MltDoubleDart = double Function();

typedef MltVoidNative = Void Function();
typedef MltVoidDart = void Function();

class MltBridge {
  MltBridge()
      : _library = DynamicLibrary.open(
          _libraryPath(),
        ) {
    _init =
        _library.lookupFunction<
            MltInitNative,
            MltInitDart>(
      'mlt_bridge_init',
    );

    _version =
        _library.lookupFunction<
            MltVersionNative,
            MltVersionDart>(
      'mlt_bridge_version',
    );

    _lastError =
        _library.lookupFunction<
            MltStringNative,
            MltStringDart>(
      'mlt_bridge_last_error',
    );

    _textureId =
        _library.lookupFunction<
            MltInt64Native,
            MltInt64Dart>(
      'mlt_bridge_texture_id',
    );

    _open =
        _library.lookupFunction<
            MltOpenNative,
            MltOpenDart>(
      'mlt_bridge_open',
    );

    _play =
        _library.lookupFunction<
            MltCommandNative,
            MltCommandDart>(
      'mlt_bridge_play',
    );

    _pause =
        _library.lookupFunction<
            MltCommandNative,
            MltCommandDart>(
      'mlt_bridge_pause',
    );

    _seek =
        _library.lookupFunction<
            MltSeekNative,
            MltSeekDart>(
      'mlt_bridge_seek_ms',
    );

    _positionMs =
        _library.lookupFunction<
            MltInt64Native,
            MltInt64Dart>(
      'mlt_bridge_position_ms',
    );

    _isPlaying =
        _library.lookupFunction<
            MltCommandNative,
            MltCommandDart>(
      'mlt_bridge_is_playing',
    );

    _durationFrames =
        _library.lookupFunction<
            MltInt64Native,
            MltInt64Dart>(
      'mlt_bridge_duration_frames',
    );

    _durationMs =
        _library.lookupFunction<
            MltInt64Native,
            MltInt64Dart>(
      'mlt_bridge_duration_ms',
    );

    _fps =
        _library.lookupFunction<
            MltDoubleNative,
            MltDoubleDart>(
      'mlt_bridge_fps',
    );

    _width =
        _library.lookupFunction<
            MltInt32Native,
            MltInt32Dart>(
      'mlt_bridge_width',
    );

    _height =
        _library.lookupFunction<
            MltInt32Native,
            MltInt32Dart>(
      'mlt_bridge_height',
    );

    _closeMedia =
        _library.lookupFunction<
            MltVoidNative,
            MltVoidDart>(
      'mlt_bridge_close_media',
    );

    _shutdown =
        _library.lookupFunction<
            MltVoidNative,
            MltVoidDart>(
      'mlt_bridge_shutdown',
    );
  }

  final DynamicLibrary _library;

  late final MltInitDart _init;
  late final MltVersionDart _version;
  late final MltStringDart _lastError;
  late final MltInt64Dart _textureId;

  late final MltOpenDart _open;
  late final MltCommandDart _play;
  late final MltCommandDart _pause;
  late final MltSeekDart _seek;

  late final MltInt64Dart _positionMs;
  late final MltCommandDart _isPlaying;

  late final MltInt64Dart _durationFrames;
  late final MltInt64Dart _durationMs;
  late final MltDoubleDart _fps;
  late final MltInt32Dart _width;
  late final MltInt32Dart _height;

  late final MltVoidDart _closeMedia;
  late final MltVoidDart _shutdown;

  static String _libraryPath() {
    final executableDirectory =
        File(
          Platform.resolvedExecutable,
        ).parent.path;

    return '$executableDirectory/'
        'lib/libmlt_bridge.so';
  }

  bool initialize() {
    return _init() != 0;
  }

  String get version {
    return _version().toDartString();
  }

  String get lastError {
    return _lastError().toDartString();
  }

  int get textureId {
    return _textureId();
  }

  bool open(String path) {
    final nativePath =
        path.toNativeUtf8(
      allocator: malloc,
    );

    try {
      return _open(nativePath) != 0;
    } finally {
      malloc.free(nativePath);
    }
  }

  bool play() {
    return _play() != 0;
  }

  bool pause() {
    return _pause() != 0;
  }

  bool seekMs(int milliseconds) {
    return _seek(milliseconds) != 0;
  }

  int get positionMs {
    return _positionMs();
  }

  bool get isPlaying {
    return _isPlaying() != 0;
  }

  int get durationFrames {
    return _durationFrames();
  }

  int get durationMs {
    return _durationMs();
  }

  double get fps {
    return _fps();
  }

  int get width {
    return _width();
  }

  int get height {
    return _height();
  }

  void closeMedia() {
    _closeMedia();
  }

  void shutdown() {
    _shutdown();
  }
}

class MediaInfo {
  const MediaInfo({
    required this.path,
    required this.name,
    required this.width,
    required this.height,
    required this.fps,
    required this.frames,
    required this.durationMs,
  });

  final String path;
  final String name;

  final int width;
  final int height;

  final double fps;
  final int frames;
  final int durationMs;
}

void main() {
  WidgetsFlutterBinding.ensureInitialized();

  final bridge =
      MltBridge();

  final initialized =
      bridge.initialize();

  runApp(
    MltPlayerApp(
      bridge: bridge,
      initialized: initialized,
      version: bridge.version,
    ),
  );
}

class MltPlayerApp extends StatelessWidget {
  const MltPlayerApp({
    super.key,
    required this.bridge,
    required this.initialized,
    required this.version,
  });

  final MltBridge bridge;
  final bool initialized;
  final String version;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'MLT Player',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        brightness: Brightness.dark,
        useMaterial3: true,
      ),
      home: PlayerPage(
        bridge: bridge,
        initialized: initialized,
        version: version,
      ),
    );
  }
}

class PlayerPage extends StatefulWidget {
  const PlayerPage({
    super.key,
    required this.bridge,
    required this.initialized,
    required this.version,
  });

  final MltBridge bridge;
  final bool initialized;
  final String version;

  @override
  State<PlayerPage> createState() =>
      _PlayerPageState();
}

class _PlayerPageState
    extends State<PlayerPage> {
  MediaInfo? _media;

  Timer? _positionTimer;

  String? _error;

  bool _opening = false;
  bool _isPlaying = false;
  bool _draggingSeekBar = false;

  int _textureId = -1;
  int _positionMs = 0;

  double _dragPositionMs = 0;

  @override
  void initState() {
    super.initState();

    _textureId =
        widget.bridge.textureId;

    _positionTimer =
        Timer.periodic(
      const Duration(
        milliseconds: 100,
      ),
      (_) => _pollNativeState(),
    );
  }

  @override
  void dispose() {
    _positionTimer?.cancel();

    widget.bridge.shutdown();

    super.dispose();
  }

  void _pollNativeState() {
    if (!mounted) {
      return;
    }

    final nativeTextureId =
        widget.bridge.textureId;

    final textureChanged =
        nativeTextureId > 0 &&
        nativeTextureId != _textureId;

    if (_media == null) {
      if (textureChanged) {
        setState(() {
          _textureId =
              nativeTextureId;
        });
      }

      return;
    }

    final position =
        widget.bridge.positionMs;

    final playing =
        widget.bridge.isPlaying;

    if (_draggingSeekBar) {
      if (textureChanged ||
          _isPlaying != playing) {
        setState(() {
          if (textureChanged) {
            _textureId =
                nativeTextureId;
          }

          _isPlaying =
              playing;
        });
      }

      return;
    }

    if (textureChanged ||
        _positionMs != position ||
        _isPlaying != playing) {
      setState(() {
        if (textureChanged) {
          _textureId =
              nativeTextureId;
        }

        _positionMs =
            position;

        _isPlaying =
            playing;
      });
    }
  }

  Future<void> _openMedia() async {
    if (!widget.initialized ||
        _opening) {
      return;
    }

    setState(() {
      _opening = true;
      _error = null;
    });

    try {
      final XFile? selectedFile =
          await openFile(
        confirmButtonText: 'Open',
      );

      if (selectedFile == null) {
        if (mounted) {
          setState(() {
            _opening = false;
          });
        }

        return;
      }

      final path =
          selectedFile.path;

      final opened =
          widget.bridge.open(path);

      if (!opened) {
        if (mounted) {
          setState(() {
            _opening = false;
            _media = null;
            _isPlaying = false;
            _positionMs = 0;

            _error =
                widget.bridge.lastError;
          });
        }

        return;
      }

      final media =
          MediaInfo(
        path: path,
        name: _basename(path),
        width: widget.bridge.width,
        height: widget.bridge.height,
        fps: widget.bridge.fps,
        frames:
            widget.bridge.durationFrames,
        durationMs:
            widget.bridge.durationMs,
      );

      if (mounted) {
        setState(() {
          _opening = false;

          _media = media;

          _textureId =
              widget.bridge.textureId;

          _isPlaying = false;

          _positionMs = 0;
          _dragPositionMs = 0;

          _error = null;
        });
      }
    } catch (error) {
      if (mounted) {
        setState(() {
          _opening = false;
          _error =
              error.toString();
        });
      }
    }
  }

  void _togglePlayback() {
    if (_media == null) {
      return;
    }

    if (_isPlaying) {
      final success =
          widget.bridge.pause();

      if (!success) {
        setState(() {
          _error =
              widget.bridge.lastError;
        });

        return;
      }

      setState(() {
        _isPlaying = false;

        _positionMs =
            widget.bridge.positionMs;

        _error = null;
      });

      return;
    }

    final success =
        widget.bridge.play();

    if (!success) {
      setState(() {
        _error =
            widget.bridge.lastError;
      });

      return;
    }

    setState(() {
      _isPlaying = true;
      _error = null;
    });
  }

  void _seekRelative(
    int deltaMs,
  ) {
    final media = _media;

    if (media == null) {
      return;
    }

    var target =
        _positionMs + deltaMs;

    if (target < 0) {
      target = 0;
    }

    if (target >
        media.durationMs) {
      target =
          media.durationMs;
    }

    _performSeek(target);
  }

  void _performSeek(
    int targetMs,
  ) {
    final media = _media;

    if (media == null) {
      return;
    }

    var clamped = targetMs;

    if (clamped < 0) {
      clamped = 0;
    }

    if (clamped >
        media.durationMs) {
      clamped =
          media.durationMs;
    }

    final success =
        widget.bridge.seekMs(
      clamped,
    );

    if (!success) {
      setState(() {
        _error =
            widget.bridge.lastError;
      });

      return;
    }

    setState(() {
      _positionMs =
          clamped;

      _dragPositionMs =
          clamped.toDouble();

      _error = null;
    });
  }

  String _basename(
    String path,
  ) {
    final normalized =
        path.replaceAll(
      '\\',
      '/',
    );

    final slash =
        normalized.lastIndexOf('/');

    if (slash == -1) {
      return normalized;
    }

    return normalized.substring(
      slash + 1,
    );
  }

  String _formatDuration(
    int milliseconds,
  ) {
    if (milliseconds < 0) {
      milliseconds = 0;
    }

    final duration =
        Duration(
      milliseconds: milliseconds,
    );

    final hours =
        duration.inHours;

    final minutes =
        duration.inMinutes
            .remainder(60);

    final seconds =
        duration.inSeconds
            .remainder(60);

    if (hours > 0) {
      return '${hours.toString().padLeft(2, '0')}:'
          '${minutes.toString().padLeft(2, '0')}:'
          '${seconds.toString().padLeft(2, '0')}';
    }

    return '${minutes.toString().padLeft(2, '0')}:'
        '${seconds.toString().padLeft(2, '0')}';
  }

  String _formatResolution(
    MediaInfo media,
  ) {
    if (media.width <= 0 ||
        media.height <= 0) {
      return '—';
    }

    return '${media.width} × '
        '${media.height}';
  }

  String _formatFps(
    double fps,
  ) {
    if (fps <= 0) {
      return '—';
    }

    return fps.toStringAsFixed(
      3,
    );
  }

  Widget _buildViewport(
    MediaInfo? media,
  ) {
    if (media == null) {
      return const Center(
        child: Column(
          mainAxisSize:
              MainAxisSize.min,
          children: [
            Icon(
              Icons.movie_outlined,
              size: 72,
            ),
            SizedBox(height: 16),
            Text(
              'No media loaded',
              style: TextStyle(
                fontSize: 20,
              ),
            ),
          ],
        ),
      );
    }

    if (_textureId <= 0) {
      return const Center(
        child: Column(
          mainAxisSize:
              MainAxisSize.min,
          children: [
            CircularProgressIndicator(),
            SizedBox(height: 16),
            Text(
              'Waiting for native '
              'Flutter texture…',
            ),
          ],
        ),
      );
    }

    final aspectRatio =
        media.width > 0 &&
                media.height > 0
            ? media.width /
                media.height
            : 16 / 9;

    return Center(
      child: AspectRatio(
        aspectRatio: aspectRatio,
        child: Texture(
          textureId: _textureId,
          filterQuality:
              FilterQuality.medium,
        ),
      ),
    );
  }

  @override
  Widget build(
    BuildContext context,
  ) {
    final media =
        _media;

    final durationMs =
        media?.durationMs ?? 0;

    final sliderMax =
        durationMs > 0
            ? durationMs.toDouble()
            : 1.0;

    final sliderValue =
        _draggingSeekBar
            ? _dragPositionMs.clamp(
                0.0,
                sliderMax,
              )
            : _positionMs
                .toDouble()
                .clamp(
                  0.0,
                  sliderMax,
                );

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'MLT Player',
        ),
        actions: [
          Padding(
            padding:
                const EdgeInsets.only(
              right: 16,
            ),
            child: Center(
              child: Text(
                widget.initialized
                    ? 'MLT ${widget.version}'
                    : 'MLT unavailable',
                style:
                    Theme.of(context)
                        .textTheme
                        .bodySmall,
              ),
            ),
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: ColoredBox(
              color: Colors.black,
              child:
                  SizedBox.expand(
                child:
                    _buildViewport(
                  media,
                ),
              ),
            ),
          ),

          Container(
            width:
                double.infinity,
            padding:
                const EdgeInsets
                    .fromLTRB(
              20,
              14,
              20,
              20,
            ),
            child: Column(
              crossAxisAlignment:
                  CrossAxisAlignment
                      .start,
              children: [
                if (media !=
                    null) ...[
                  Row(
                    children: [
                      Text(
                        _formatDuration(
                          _draggingSeekBar
                              ? _dragPositionMs
                                  .round()
                              : _positionMs,
                        ),
                        style:
                            const TextStyle(
                          fontFeatures: [
                            FontFeature
                                .tabularFigures(),
                          ],
                        ),
                      ),

                      Expanded(
                        child: Slider(
                          min: 0,
                          max:
                              sliderMax,
                          value:
                              sliderValue,
                          onChangeStart:
                              durationMs >
                                      0
                                  ? (value) {
                                      setState(
                                        () {
                                          _draggingSeekBar =
                                              true;

                                          _dragPositionMs =
                                              value;
                                        },
                                      );
                                    }
                                  : null,
                          onChanged:
                              durationMs >
                                      0
                                  ? (value) {
                                      setState(
                                        () {
                                          _dragPositionMs =
                                              value;
                                        },
                                      );
                                    }
                                  : null,
                          onChangeEnd:
                              durationMs >
                                      0
                                  ? (value) {
                                      setState(
                                        () {
                                          _draggingSeekBar =
                                              false;
                                        },
                                      );

                                      _performSeek(
                                        value
                                            .round(),
                                      );
                                    }
                                  : null,
                        ),
                      ),

                      Text(
                        _formatDuration(
                          durationMs,
                        ),
                        style:
                            const TextStyle(
                          fontFeatures: [
                            FontFeature
                                .tabularFigures(),
                          ],
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(
                    height: 4,
                  ),

                  Row(
                    mainAxisAlignment:
                        MainAxisAlignment
                            .center,
                    children: [
                      IconButton(
                        tooltip:
                            'Back 10 seconds',
                        icon:
                            const Icon(
                          Icons.replay_10,
                        ),
                        onPressed: () =>
                            _seekRelative(
                          -10000,
                        ),
                      ),

                      const SizedBox(
                        width: 12,
                      ),

                      FilledButton
                          .tonalIcon(
                        onPressed:
                            _togglePlayback,
                        icon: Icon(
                          _isPlaying
                              ? Icons.pause
                              : Icons.play_arrow,
                        ),
                        label: Text(
                          _isPlaying
                              ? 'Pause'
                              : 'Play',
                        ),
                      ),

                      const SizedBox(
                        width: 12,
                      ),

                      IconButton(
                        tooltip:
                            'Forward 10 seconds',
                        icon:
                            const Icon(
                          Icons.forward_10,
                        ),
                        onPressed: () =>
                            _seekRelative(
                          10000,
                        ),
                      ),
                    ],
                  ),

                  const SizedBox(
                    height: 12,
                  ),
                ],

                Row(
                  children: [
                    FilledButton.icon(
                      onPressed:
                          widget.initialized &&
                                  !_opening
                              ? _openMedia
                              : null,
                      icon: _opening
                          ? const SizedBox(
                              width: 18,
                              height: 18,
                              child:
                                  CircularProgressIndicator(
                                strokeWidth:
                                    2,
                              ),
                            )
                          : const Icon(
                              Icons
                                  .folder_open,
                            ),
                      label: Text(
                        _opening
                            ? 'Opening...'
                            : 'Open Media',
                      ),
                    ),
                  ],
                ),

                if (_error != null &&
                    _error!
                        .isNotEmpty) ...[
                  const SizedBox(
                    height: 12,
                  ),
                  Text(
                    _error!,
                    style: TextStyle(
                      color:
                          Theme.of(context)
                              .colorScheme
                              .error,
                    ),
                  ),
                ],

                if (media !=
                    null) ...[
                  const SizedBox(
                    height: 16,
                  ),
                  const Divider(),
                  const SizedBox(
                    height: 10,
                  ),

                  Text(
                    media.name,
                    style:
                        Theme.of(context)
                            .textTheme
                            .titleMedium,
                  ),

                  const SizedBox(
                    height: 6,
                  ),

                  SelectableText(
                    media.path,
                    style:
                        Theme.of(context)
                            .textTheme
                            .bodySmall,
                  ),

                  const SizedBox(
                    height: 16,
                  ),

                  Wrap(
                    spacing: 32,
                    runSpacing: 16,
                    children: [
                      _InfoItem(
                        label:
                            'Resolution',
                        value:
                            _formatResolution(
                          media,
                        ),
                      ),
                      _InfoItem(
                        label:
                            'Frame rate',
                        value:
                            '${_formatFps(media.fps)} fps',
                      ),
                      _InfoItem(
                        label:
                            'Frames',
                        value:
                            media.frames >
                                    0
                                ? media
                                    .frames
                                    .toString()
                                : '—',
                      ),
                      _InfoItem(
                        label:
                            'Duration',
                        value:
                            _formatDuration(
                          media
                              .durationMs,
                        ),
                      ),
                    ],
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _InfoItem
    extends StatelessWidget {
  const _InfoItem({
    required this.label,
    required this.value,
  });

  final String label;
  final String value;

  @override
  Widget build(
    BuildContext context,
  ) {
    return SizedBox(
      width: 150,
      child: Column(
        crossAxisAlignment:
            CrossAxisAlignment
                .start,
        children: [
          Text(
            label,
            style:
                Theme.of(context)
                    .textTheme
                    .bodySmall,
          ),
          const SizedBox(
            height: 4,
          ),
          Text(
            value,
            style:
                Theme.of(context)
                    .textTheme
                    .titleMedium,
          ),
        ],
      ),
    );
  }
}