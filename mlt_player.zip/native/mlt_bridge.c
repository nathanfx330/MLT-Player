/* native/mlt_bridge.c */

#include "mlt_bridge.h"

#include <flutter_linux/flutter_linux.h>
#include <epoxy/gl.h>
#include <framework/mlt.h>

#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* ------------------------------------------------------------------------- */
/* MLT state                                                                 */
/* ------------------------------------------------------------------------- */

static mlt_repository repository = NULL;
static mlt_profile profile = NULL;
static mlt_producer producer = NULL;
static mlt_consumer consumer = NULL;

static int consumer_started = 0;

static char last_error[512] = "";

/* ------------------------------------------------------------------------- */
/* Flutter video-frame state                                                 */
/* ------------------------------------------------------------------------- */

static FlTextureRegistrar *texture_registrar = NULL;

static uint8_t *frame_buffer = NULL;
static size_t frame_buffer_size = 0;

static int frame_width = 0;
static int frame_height = 0;

static int64_t last_frame_position = -1;

static GMutex frame_mutex;
static gsize frame_mutex_initialized = 0;

static gint frame_notification_pending = 0;

/* ------------------------------------------------------------------------- */
/* Flutter OpenGL texture                                                    */
/* ------------------------------------------------------------------------- */

typedef struct _MltVideoTexture {
    FlTextureGL parent_instance;

    GLuint gl_texture_id;

    int uploaded_width;
    int uploaded_height;
} MltVideoTexture;

typedef struct _MltVideoTextureClass {
    FlTextureGLClass parent_class;
} MltVideoTextureClass;

static MltVideoTexture *video_texture = NULL;

G_DEFINE_TYPE(
    MltVideoTexture,
    mlt_video_texture,
    fl_texture_gl_get_type()
)

static void ensure_frame_mutex(void)
{
    if (g_once_init_enter(&frame_mutex_initialized)) {
        g_mutex_init(&frame_mutex);
        g_once_init_leave(&frame_mutex_initialized, 1);
    }
}

static gboolean mlt_video_texture_populate(
    FlTextureGL *texture,
    uint32_t *target,
    uint32_t *name,
    uint32_t *width,
    uint32_t *height,
    GError **error)
{
    (void)error;

    MltVideoTexture *self =
        (MltVideoTexture *)texture;

    ensure_frame_mutex();

    g_mutex_lock(&frame_mutex);

    if (frame_buffer == NULL ||
        frame_width <= 0 ||
        frame_height <= 0) {
        g_mutex_unlock(&frame_mutex);
        return FALSE;
    }

    if (self->gl_texture_id == 0) {
        glGenTextures(
            1,
            &self->gl_texture_id
        );

        glBindTexture(
            GL_TEXTURE_2D,
            self->gl_texture_id
        );

        glTexParameteri(
            GL_TEXTURE_2D,
            GL_TEXTURE_MIN_FILTER,
            GL_LINEAR
        );

        glTexParameteri(
            GL_TEXTURE_2D,
            GL_TEXTURE_MAG_FILTER,
            GL_LINEAR
        );

        glTexParameteri(
            GL_TEXTURE_2D,
            GL_TEXTURE_WRAP_S,
            GL_CLAMP_TO_EDGE
        );

        glTexParameteri(
            GL_TEXTURE_2D,
            GL_TEXTURE_WRAP_T,
            GL_CLAMP_TO_EDGE
        );
    } else {
        glBindTexture(
            GL_TEXTURE_2D,
            self->gl_texture_id
        );
    }

    glPixelStorei(
        GL_UNPACK_ALIGNMENT,
        1
    );

    if (self->uploaded_width != frame_width ||
        self->uploaded_height != frame_height) {
        glTexImage2D(
            GL_TEXTURE_2D,
            0,
            GL_RGBA8,
            frame_width,
            frame_height,
            0,
            GL_RGBA,
            GL_UNSIGNED_BYTE,
            frame_buffer
        );

        self->uploaded_width =
            frame_width;

        self->uploaded_height =
            frame_height;
    } else {
        glTexSubImage2D(
            GL_TEXTURE_2D,
            0,
            0,
            0,
            frame_width,
            frame_height,
            GL_RGBA,
            GL_UNSIGNED_BYTE,
            frame_buffer
        );
    }

    *target = GL_TEXTURE_2D;
    *name = self->gl_texture_id;
    *width = (uint32_t)frame_width;
    *height = (uint32_t)frame_height;

    g_mutex_unlock(&frame_mutex);

    return TRUE;
}

static void mlt_video_texture_class_init(
    MltVideoTextureClass *klass)
{
    FL_TEXTURE_GL_CLASS(klass)->populate =
        mlt_video_texture_populate;
}

static void mlt_video_texture_init(
    MltVideoTexture *self)
{
    self->gl_texture_id = 0;
    self->uploaded_width = 0;
    self->uploaded_height = 0;
}

/* ------------------------------------------------------------------------- */
/* Helpers                                                                   */
/* ------------------------------------------------------------------------- */

static void set_error(
    const char *message)
{
    if (message == NULL) {
        last_error[0] = '\0';
        return;
    }

    snprintf(
        last_error,
        sizeof(last_error),
        "%s",
        message
    );
}

static void clear_frame_buffer(void)
{
    ensure_frame_mutex();

    g_mutex_lock(&frame_mutex);

    free(frame_buffer);

    frame_buffer = NULL;
    frame_buffer_size = 0;

    frame_width = 0;
    frame_height = 0;

    last_frame_position = -1;

    g_mutex_unlock(&frame_mutex);
}

static void reset_last_frame_position(void)
{
    ensure_frame_mutex();

    g_mutex_lock(&frame_mutex);

    last_frame_position = -1;

    g_mutex_unlock(&frame_mutex);
}

static gboolean mark_flutter_texture_frame(
    gpointer user_data)
{
    (void)user_data;

    if (texture_registrar != NULL &&
        video_texture != NULL) {
        fl_texture_registrar_mark_texture_frame_available(
            texture_registrar,
            FL_TEXTURE(video_texture)
        );
    }

    g_atomic_int_set(
        &frame_notification_pending,
        0
    );

    return G_SOURCE_REMOVE;
}

static void notify_flutter_frame_available(void)
{
    if (texture_registrar == NULL ||
        video_texture == NULL) {
        return;
    }

    if (g_atomic_int_compare_and_exchange(
            &frame_notification_pending,
            0,
            1)) {
        g_main_context_invoke(
            NULL,
            mark_flutter_texture_frame,
            NULL
        );
    }
}

/* ------------------------------------------------------------------------- */
/* MLT -> Flutter frame callback                                             */
/* ------------------------------------------------------------------------- */

static void on_consumer_frame_show(
    mlt_properties owner,
    void *listener_data,
    mlt_event_data event_data)
{
    (void)owner;
    (void)listener_data;

    mlt_frame frame =
        mlt_event_data_to_frame(
            event_data
        );

    if (frame == NULL) {
        return;
    }

    const int64_t position =
        (int64_t)mlt_frame_get_position(
            frame
        );

    ensure_frame_mutex();

    g_mutex_lock(&frame_mutex);

    const int already_have_frame =
        position == last_frame_position &&
        frame_buffer != NULL;

    g_mutex_unlock(&frame_mutex);

    if (already_have_frame) {
        return;
    }

    mlt_properties frame_properties =
        MLT_FRAME_PROPERTIES(frame);

    mlt_properties_set(
        frame_properties,
        "consumer.rescale",
        "bilinear"
    );

    mlt_properties_set(
        frame_properties,
        "consumer.deinterlacer",
        "onefield"
    );

    mlt_properties_set_int(
        frame_properties,
        "consumer.top_field_first",
        -1
    );

    mlt_image_format format =
        mlt_image_rgba;

    uint8_t *image = NULL;

    int width =
        profile != NULL
            ? profile->width
            : 0;

    int height =
        profile != NULL
            ? profile->height
            : 0;

    const int image_error =
        mlt_frame_get_image(
            frame,
            &image,
            &format,
            &width,
            &height,
            0
        );

    if (image_error != 0 ||
        image == NULL ||
        width <= 0 ||
        height <= 0) {
        return;
    }

    const size_t required_size =
        (size_t)width *
        (size_t)height *
        4u;

    ensure_frame_mutex();

    g_mutex_lock(&frame_mutex);

    if (required_size >
        frame_buffer_size) {
        uint8_t *new_buffer =
            realloc(
                frame_buffer,
                required_size
            );

        if (new_buffer == NULL) {
            g_mutex_unlock(
                &frame_mutex
            );
            return;
        }

        frame_buffer =
            new_buffer;

        frame_buffer_size =
            required_size;
    }

    memcpy(
        frame_buffer,
        image,
        required_size
    );

    frame_width = width;
    frame_height = height;

    last_frame_position =
        position;

    g_mutex_unlock(&frame_mutex);

    notify_flutter_frame_available();
}

/* ------------------------------------------------------------------------- */
/* Flutter texture registration                                              */
/* ------------------------------------------------------------------------- */

MLT_BRIDGE_EXPORT
int64_t mlt_bridge_register_flutter_texture(
    FlTextureRegistrar *registrar)
{
    if (registrar == NULL) {
        return -1;
    }

    if (video_texture != NULL &&
        texture_registrar != NULL) {
        return fl_texture_get_id(
            FL_TEXTURE(video_texture)
        );
    }

    ensure_frame_mutex();

    texture_registrar =
        FL_TEXTURE_REGISTRAR(
            g_object_ref(registrar)
        );

    video_texture =
        (MltVideoTexture *)
            g_object_new(
                mlt_video_texture_get_type(),
                NULL
            );

    if (video_texture == NULL) {
        g_object_unref(
            texture_registrar
        );

        texture_registrar = NULL;

        return -1;
    }

    if (!fl_texture_registrar_register_texture(
            texture_registrar,
            FL_TEXTURE(video_texture))) {
        g_object_unref(
            video_texture
        );

        video_texture = NULL;

        g_object_unref(
            texture_registrar
        );

        texture_registrar = NULL;

        return -1;
    }

    return fl_texture_get_id(
        FL_TEXTURE(video_texture)
    );
}

MLT_BRIDGE_EXPORT
void mlt_bridge_unregister_flutter_texture(void)
{
    if (texture_registrar != NULL &&
        video_texture != NULL) {
        fl_texture_registrar_unregister_texture(
            texture_registrar,
            FL_TEXTURE(video_texture)
        );
    }

    if (video_texture != NULL) {
        g_object_unref(
            video_texture
        );

        video_texture = NULL;
    }

    if (texture_registrar != NULL) {
        g_object_unref(
            texture_registrar
        );

        texture_registrar = NULL;
    }

    clear_frame_buffer();
}

MLT_BRIDGE_EXPORT
int64_t mlt_bridge_texture_id(void)
{
    if (video_texture == NULL) {
        return -1;
    }

    return fl_texture_get_id(
        FL_TEXTURE(video_texture)
    );
}

/* ------------------------------------------------------------------------- */
/* MLT consumer / producer                                                   */
/* ------------------------------------------------------------------------- */

static void close_consumer(void)
{
    if (consumer != NULL) {
        if (!mlt_consumer_is_stopped(
                consumer)) {
            mlt_consumer_stop(
                consumer
            );
        }

        mlt_consumer_close(
            consumer
        );

        consumer = NULL;
    }

    consumer_started = 0;
}

static void close_producer(void)
{
    close_consumer();

    if (producer != NULL) {
        mlt_producer_close(
            producer
        );

        producer = NULL;
    }
}

static void reset_profile(void)
{
    if (profile != NULL) {
        mlt_profile_close(
            profile
        );

        profile = NULL;
    }

    profile =
        mlt_profile_init(NULL);
}

static int create_consumer(void)
{
    if (producer == NULL ||
        profile == NULL) {
        set_error(
            "No producer is loaded."
        );

        return 0;
    }

    if (consumer != NULL) {
        return 1;
    }

    consumer =
        mlt_factory_consumer(
            profile,
            "sdl2_audio",
            NULL
        );

    if (consumer == NULL) {
        set_error(
            "Could not create the MLT "
            "sdl2_audio consumer."
        );

        return 0;
    }

    mlt_properties properties =
        MLT_CONSUMER_PROPERTIES(
            consumer
        );

    mlt_properties_set_int(
        properties,
        "real_time",
        1
    );

    mlt_properties_set_int(
        properties,
        "terminate_on_pause",
        0
    );

    mlt_properties_set_int(
        properties,
        "scrub_audio",
        0
    );

    mlt_properties_set_double(
        properties,
        "volume",
        1.0
    );

    mlt_events_listen(
        properties,
        NULL,
        "consumer-frame-show",
        (mlt_listener)
            on_consumer_frame_show
    );

    const int connect_result =
        mlt_consumer_connect(
            consumer,
            MLT_PRODUCER_SERVICE(
                producer
            )
        );

    if (connect_result != 0) {
        mlt_consumer_close(
            consumer
        );

        consumer = NULL;

        set_error(
            "MLT could not connect the "
            "audio consumer to the producer."
        );

        return 0;
    }

    return 1;
}

/* ------------------------------------------------------------------------- */
/* Public MLT API                                                            */
/* ------------------------------------------------------------------------- */

MLT_BRIDGE_EXPORT
int mlt_bridge_init(void)
{
    if (repository != NULL) {
        return 1;
    }

    repository =
        mlt_factory_init(NULL);

    if (repository == NULL) {
        set_error(
            "Failed to initialize MLT."
        );

        return 0;
    }

    profile =
        mlt_profile_init(NULL);

    if (profile == NULL) {
        set_error(
            "Failed to create the MLT profile."
        );

        return 0;
    }

    set_error(NULL);

    return 1;
}

MLT_BRIDGE_EXPORT
const char *mlt_bridge_version(void)
{
    return mlt_version_get_string();
}

MLT_BRIDGE_EXPORT
const char *mlt_bridge_last_error(void)
{
    return last_error;
}

MLT_BRIDGE_EXPORT
int mlt_bridge_open(
    const char *path)
{
    if (repository == NULL ||
        path == NULL) {
        set_error(
            "MLT is not initialized "
            "or the path is invalid."
        );

        return 0;
    }

    close_producer();
    reset_profile();
    clear_frame_buffer();

    if (profile == NULL) {
        set_error(
            "Could not create an MLT profile."
        );

        return 0;
    }

    mlt_producer probe_producer =
        mlt_factory_producer(
            profile,
            NULL,
            path
        );

    if (probe_producer == NULL) {
        set_error(
            "MLT could not open "
            "the selected media."
        );

        return 0;
    }

    mlt_producer_probe(
        probe_producer
    );

    mlt_profile_from_producer(
        profile,
        probe_producer
    );

    mlt_producer_close(
        probe_producer
    );

    producer =
        mlt_factory_producer(
            profile,
            NULL,
            path
        );

    if (producer == NULL) {
        set_error(
            "MLT could not reopen the media "
            "with the detected profile."
        );

        return 0;
    }

    mlt_producer_probe(
        producer
    );

    mlt_producer_set_speed(
        producer,
        0.0
    );

    mlt_producer_seek(
        producer,
        0
    );

    if (!create_consumer()) {
        close_producer();
        return 0;
    }

    if (mlt_consumer_start(
            consumer) != 0) {
        set_error(
            "MLT could not start "
            "the audio/preview consumer."
        );

        close_producer();

        return 0;
    }

    consumer_started = 1;

    mlt_properties_set_int(
        MLT_CONSUMER_PROPERTIES(
            consumer
        ),
        "refresh",
        1
    );

    set_error(NULL);

    return 1;
}

MLT_BRIDGE_EXPORT
int mlt_bridge_play(void)
{
    if (producer == NULL) {
        set_error(
            "No media is loaded."
        );

        return 0;
    }

    if (!create_consumer()) {
        return 0;
    }

    const mlt_position length =
        mlt_producer_get_length(
            producer
        );

    mlt_position position =
        mlt_producer_position(
            producer
        );

    if (length > 0 &&
        position >= length - 1) {
        mlt_consumer_purge(
            consumer
        );

        mlt_producer_seek(
            producer,
            0
        );

        reset_last_frame_position();
    }

    mlt_producer_set_speed(
        producer,
        1.0
    );

    mlt_consumer_purge(
        consumer
    );

    if (mlt_consumer_start(
            consumer) != 0) {
        set_error(
            "MLT could not start playback."
        );

        return 0;
    }

    consumer_started = 1;

    mlt_properties_set_int(
        MLT_CONSUMER_PROPERTIES(
            consumer
        ),
        "refresh",
        1
    );

    set_error(NULL);

    return 1;
}

MLT_BRIDGE_EXPORT
int mlt_bridge_pause(void)
{
    if (producer == NULL) {
        return 0;
    }

    if (consumer == NULL) {
        mlt_producer_set_speed(
            producer,
            0.0
        );

        return 1;
    }

    mlt_position position =
        mlt_consumer_position(
            consumer
        ) + 1;

    const mlt_position length =
        mlt_producer_get_length(
            producer
        );

    if (position < 0) {
        position = 0;
    }

    if (length > 0 &&
        position >= length) {
        position =
            length - 1;
    }

    mlt_producer_set_speed(
        producer,
        0.0
    );

    mlt_consumer_purge(
        consumer
    );

    mlt_producer_seek(
        producer,
        position
    );

    reset_last_frame_position();

    mlt_properties_set_int(
        MLT_CONSUMER_PROPERTIES(
            consumer
        ),
        "refresh",
        1
    );

    set_error(NULL);

    return 1;
}

MLT_BRIDGE_EXPORT
int mlt_bridge_seek_ms(
    int64_t milliseconds)
{
    if (producer == NULL) {
        return 0;
    }

    const double fps =
        mlt_producer_get_fps(
            producer
        );

    if (fps <= 0.0) {
        set_error(
            "Producer has an invalid frame rate."
        );

        return 0;
    }

    mlt_position frame =
        (mlt_position)(
            ((double)milliseconds /
             1000.0) *
            fps
        );

    const mlt_position length =
        mlt_producer_get_length(
            producer
        );

    if (frame < 0) {
        frame = 0;
    }

    if (length > 0 &&
        frame >= length) {
        frame =
            length - 1;
    }

    if (consumer != NULL) {
        mlt_consumer_purge(
            consumer
        );
    }

    if (mlt_producer_seek(
            producer,
            frame) != 0) {
        set_error(
            "MLT seek failed."
        );

        return 0;
    }

    reset_last_frame_position();

    if (consumer != NULL) {
        if (mlt_consumer_start(
                consumer) != 0) {
            set_error(
                "MLT could not refresh "
                "after seeking."
            );

            return 0;
        }

        consumer_started = 1;

        mlt_properties_set_int(
            MLT_CONSUMER_PROPERTIES(
                consumer
            ),
            "refresh",
            1
        );
    }

    set_error(NULL);

    return 1;
}

MLT_BRIDGE_EXPORT
int64_t mlt_bridge_position_ms(void)
{
    if (producer == NULL) {
        return 0;
    }

    const double fps =
        mlt_producer_get_fps(
            producer
        );

    if (fps <= 0.0) {
        return 0;
    }

    mlt_position position;

    if (consumer != NULL &&
        consumer_started) {
        position =
            mlt_consumer_position(
                consumer
            );
    } else {
        position =
            mlt_producer_position(
                producer
            );
    }

    if (position < 0) {
        position = 0;
    }

    return (int64_t)(
        ((double)position / fps) *
        1000.0
    );
}

MLT_BRIDGE_EXPORT
int mlt_bridge_is_playing(void)
{
    if (producer == NULL ||
        consumer == NULL ||
        !consumer_started) {
        return 0;
    }

    if (mlt_consumer_is_stopped(
            consumer)) {
        return 0;
    }

    return
        mlt_producer_get_speed(
            producer
        ) != 0.0;
}

MLT_BRIDGE_EXPORT
int64_t mlt_bridge_duration_frames(void)
{
    if (producer == NULL) {
        return 0;
    }

    return (int64_t)
        mlt_producer_get_length(
            producer
        );
}

MLT_BRIDGE_EXPORT
double mlt_bridge_fps(void)
{
    if (producer == NULL) {
        return 0.0;
    }

    return mlt_producer_get_fps(
        producer
    );
}

MLT_BRIDGE_EXPORT
int64_t mlt_bridge_duration_ms(void)
{
    if (producer == NULL) {
        return 0;
    }

    const double fps =
        mlt_producer_get_fps(
            producer
        );

    if (fps <= 0.0) {
        return 0;
    }

    const int64_t frames =
        (int64_t)
            mlt_producer_get_length(
                producer
            );

    return (int64_t)(
        ((double)frames / fps) *
        1000.0
    );
}

MLT_BRIDGE_EXPORT
int mlt_bridge_width(void)
{
    if (producer == NULL) {
        return 0;
    }

    mlt_properties properties =
        MLT_PRODUCER_PROPERTIES(
            producer
        );

    int width =
        mlt_properties_get_int(
            properties,
            "meta.media.width"
        );

    if (width <= 0) {
        width =
            mlt_properties_get_int(
                properties,
                "width"
            );
    }

    return width;
}

MLT_BRIDGE_EXPORT
int mlt_bridge_height(void)
{
    if (producer == NULL) {
        return 0;
    }

    mlt_properties properties =
        MLT_PRODUCER_PROPERTIES(
            producer
        );

    int height =
        mlt_properties_get_int(
            properties,
            "meta.media.height"
        );

    if (height <= 0) {
        height =
            mlt_properties_get_int(
                properties,
                "height"
            );
    }

    return height;
}

MLT_BRIDGE_EXPORT
void mlt_bridge_close_media(void)
{
    close_producer();
    clear_frame_buffer();
}

MLT_BRIDGE_EXPORT
void mlt_bridge_shutdown(void)
{
    close_producer();

    if (profile != NULL) {
        mlt_profile_close(
            profile
        );

        profile = NULL;
    }

    if (repository != NULL) {
        mlt_factory_close();

        repository = NULL;
    }

    clear_frame_buffer();
}