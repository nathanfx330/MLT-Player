/* native/mlt_bridge.h */

#ifndef MLT_PLAYER_MLT_BRIDGE_H
#define MLT_PLAYER_MLT_BRIDGE_H

#include <stdint.h>

typedef struct _FlTextureRegistrar FlTextureRegistrar;

#if defined(__GNUC__)
#define MLT_BRIDGE_EXPORT __attribute__((visibility("default")))
#else
#define MLT_BRIDGE_EXPORT
#endif

#ifdef __cplusplus
extern "C" {
#endif

MLT_BRIDGE_EXPORT int64_t
mlt_bridge_register_flutter_texture(
    FlTextureRegistrar *registrar
);

MLT_BRIDGE_EXPORT void
mlt_bridge_unregister_flutter_texture(void);

MLT_BRIDGE_EXPORT int64_t
mlt_bridge_texture_id(void);

MLT_BRIDGE_EXPORT int
mlt_bridge_init(void);

MLT_BRIDGE_EXPORT const char *
mlt_bridge_version(void);

MLT_BRIDGE_EXPORT const char *
mlt_bridge_last_error(void);

MLT_BRIDGE_EXPORT int
mlt_bridge_open(
    const char *path
);

MLT_BRIDGE_EXPORT int
mlt_bridge_play(void);

MLT_BRIDGE_EXPORT int
mlt_bridge_pause(void);

MLT_BRIDGE_EXPORT int
mlt_bridge_seek_ms(
    int64_t milliseconds
);

MLT_BRIDGE_EXPORT int64_t
mlt_bridge_position_ms(void);

MLT_BRIDGE_EXPORT int
mlt_bridge_is_playing(void);

MLT_BRIDGE_EXPORT int64_t
mlt_bridge_duration_frames(void);

MLT_BRIDGE_EXPORT double
mlt_bridge_fps(void);

MLT_BRIDGE_EXPORT int64_t
mlt_bridge_duration_ms(void);

MLT_BRIDGE_EXPORT int
mlt_bridge_width(void);

MLT_BRIDGE_EXPORT int
mlt_bridge_height(void);

MLT_BRIDGE_EXPORT void
mlt_bridge_close_media(void);

MLT_BRIDGE_EXPORT void
mlt_bridge_shutdown(void);

#ifdef __cplusplus
}
#endif

#endif