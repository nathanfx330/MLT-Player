/* native/mlt_smoke.c */

#include <stdio.h>
#include <framework/mlt.h>

int main(void)
{
    mlt_repository repository = mlt_factory_init(NULL);

    if (!repository) {
        fprintf(stderr, "Failed to initialize MLT.\n");
        return 1;
    }

    printf("MLT initialized successfully.\n");
    printf("MLT version: %s\n", mlt_version_get_string());
    printf("MLT module directory: %s\n", mlt_factory_directory());

    mlt_factory_close();

    return 0;
}
